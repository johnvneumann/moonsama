options(max.print = 1e5)
remove(list = ls()); ls()

data2 = read.csv('./input/moonsama_v2.csv', sep = ';'); names(data2)
data3 = read.csv('./input/moonsama_v3.csv', sep = ';'); names(data3)

# Data 2-3 - lineal version ####
par(mfrow = c(1,2))
plot(data2$total_score,
     data2$ID,
     main = 'Moonsama Rarity Index Plot',
     xlab = 'Rarity Index',
     ylab = 'NFT ID')
hist(data2$total_score,
     main = 'Histogram: Moonsama Rarity Index',
     xlab = 'Rarity Index',
     ylab = 'NFTs')

par(mfrow = c(1,3))
boxplot(data2$total_score,
        main = 'Moonsama Rarity Index Boxplot',
        ylab = 'Rarity Index')
plot(data2$atributes,
     data2$total_score,
     main = 'Rarity Distribution per Quantity of Atributes',
     xlab = 'Atributes',
     ylab = 'Rarity Index')
plot(data3$rank,
     data3$total_score,
     main = 'Moonsama Rarity Index Plot',
     xlab = 'Rank',
     ylab = 'Rarity Index')

# Data 2-3 - Log version ####
par(mfrow = c(1,2))
plot(data2$total_score,
     data2$ID,
     log = 'x',
     main = 'Moonsama Rarity Index Plot',
     xlab = 'Rarity Index (log-scaled)',
     ylab = 'NFT ID')
hist(log(data2$total_score),
     main = 'Histogram: Moonsama Rarity Index',
     xlab = 'log(Rarity Index)',
     ylab = 'NFTs')

par(mfrow = c(1,3))
boxplot(log(data2$total_score),
        main = 'Moonsama Rarity Index Boxplot',
        ylab = 'log(Rarity Index)')
plot(data2$atributes,
     data2$total_score,
     log = 'y',
     main = 'Rarity Distribution per Quantity of Atributes',
     xlab = 'Atributes',
     ylab = 'Rarity Index (log-scaled)')
plot(data3$rank,
     data3$total_score,
     log = 'y',
     main = 'Moonsama Rarity Index Plot',
     xlab = 'Rank',
     ylab = 'Rarity Index (log-scaled)')
