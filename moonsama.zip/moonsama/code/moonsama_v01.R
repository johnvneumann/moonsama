options(max.print = 1e5)
remove(list = ls()); ls()

data1 = read.csv('./input/moonsama_v1.csv', sep = ';'); names(data1)

# Data 1 ####
par(mfrow = c(2,2))
plot(data1$ID,
     data1$average_rarity,
     main = 'Moonsama Rarity Index Plot',
     xlab = 'NFT ID',
     ylab = 'Rarity Index')
hist(data1$average_rarity,
     main = 'Histogram: Moonsama Rarity Index',
     xlab = 'Rarity Index',
     ylab = 'NFTs')
boxplot(data1$average_rarity,
        main = 'Moonsama Rarity Index Boxplot',
        ylab = 'Rarity Index')
plot(data1$average_rarity,
     data1$atributes,
     main = 'Rarity Distribution per Quantity of Atributes',
     ylab = 'Atributes',
     xlab = 'Rarity Index')
